package com.demoMail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMailAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMailAppApplication.class, args);
	}

}
