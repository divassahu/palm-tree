package com.demoMail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMailAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
